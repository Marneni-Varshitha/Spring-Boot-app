package com.example.bfh.service;

import com.example.bfh.dto.GenerateWebhookRequest;
import com.example.bfh.dto.GenerateWebhookResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class HiringClient {
  private static final Logger log = LoggerFactory.getLogger(HiringClient.class);

  private static final String GENERATE_WEBHOOK_URL =
      "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";

  private final WebClient webClient;

  public HiringClient(WebClient webClient) {
    this.webClient = webClient;
  }

  public Mono<GenerateWebhookResponse> generateWebhook(GenerateWebhookRequest req) {
    log.info("Calling generateWebhook for regNo={} ...", req.getRegNo());

    return webClient.post()
        .uri(GENERATE_WEBHOOK_URL)
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(req)
        .retrieve()
        .bodyToMono(GenerateWebhookResponse.class)
        .doOnNext(resp -> log.info("Received webhook response: {}", resp));
  }

  public Mono<String> submitFinalQuery(String webhookUrl, String jwtToken, String finalSql) {
    log.info("Submitting finalQuery to webhook: {}", webhookUrl);

    record Payload(String finalQuery) {}

    return webClient.post()
        .uri(webhookUrl)
        .header("Authorization", jwtToken == null ? "" : jwtToken)
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(new Payload(finalSql))
        .retrieve()
        .bodyToMono(String.class)
        .doOnNext(body -> log.info("Submission response: {}", body));
  }
}
