package com.example.bfh.service;

import com.example.bfh.dto.GenerateWebhookRequest;
import com.example.bfh.dto.GenerateWebhookResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
public class QualifierRunner implements CommandLineRunner {
  private static final Logger log = LoggerFactory.getLogger(QualifierRunner.class);

  @Value("${bfh.name}")
  private String name;

  @Value("${bfh.regNo}")
  private String regNo;

  @Value("${bfh.email}")
  private String email;

  @Value("${bfh.final-sql:}")
  private String injectedFinalSql;

  private final HiringClient client;

  public QualifierRunner(HiringClient client) {
    this.client = client;
  }

  @Override
  public void run(String... args) {
    log.info("==== BFH Qualifier app started ====");
    log.info("Using candidate: name='{}', regNo='{}', email='{}'", name, regNo, email);

    GenerateWebhookRequest req = new GenerateWebhookRequest(name, regNo, email);

    Mono<GenerateWebhookResponse> flow = client.generateWebhook(req)
        .flatMap(resp -> {
          String webhook = resp.getWebhook();
          String token   = resp.getAccessToken();

          if (webhook == null || webhook.isBlank()) {
            return Mono.error(new IllegalStateException("No webhook URL received"));
          }
          if (token == null || token.isBlank()) {
            return Mono.error(new IllegalStateException("No accessToken received"));
          }

          String finalSql = computeFinalSql(regNo);
          log.info("Final SQL to submit:\n{}", finalSql);

          return client.submitFinalQuery(webhook, token, finalSql);
        });

    try {
      String submissionResponse = flow.block();
      log.info("==== Submission completed successfully ====");
      log.info("Server response: {}", submissionResponse);
    } catch (Exception e) {
      log.error("Flow failed: {}", e.getMessage(), e);
    }
  }

  private String computeFinalSql(String regNo) {
    if (injectedFinalSql != null && !injectedFinalSql.isBlank()) {
      log.info("Using SQL from application.properties (bfh.final-sql).");
      return injectedFinalSql.trim();
    }

    int lastTwo = extractLastTwoDigits(regNo);
    boolean isOdd = (lastTwo % 2) == 1;

    log.info("Last two digits of regNo = {} -> {}", lastTwo, (isOdd ? "Odd (Question 1)" : "Even (Question 2)"));

    if (isOdd) {
      return "SELECT 1 AS result_for_question_1;";
    } else {
      return "SELECT 2 AS result_for_question_2;";
    }
  }

  private int extractLastTwoDigits(String regNo) {
    String digits = regNo.replaceAll("\D+", "");
    if (digits.isEmpty()) return 0;
    int num = Integer.parseInt(digits.substring(Math.max(0, digits.length() - 2)));
    return num;
  }
}
